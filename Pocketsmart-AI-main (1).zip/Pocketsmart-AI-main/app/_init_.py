"""
PocketSmart AI application package.
"""